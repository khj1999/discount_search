package com.example.discount_search

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class DiscountSearchApplicationTests {

	@Test
	fun contextLoads() {
	}

}
