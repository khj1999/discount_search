package com.example.discount_search

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class DiscountSearchApplication

fun main(args: Array<String>) {
	runApplication<DiscountSearchApplication>(*args)
}
